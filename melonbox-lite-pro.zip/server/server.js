const app=require("./server.dll");
// https://www.expressjs.com.cn/4x/api.html
const mysql=require("./mysql.dll");
// https://github.com/mysqljs/mysql

const pool = mysql.createPool({
  connectionLimit : 10,
  host            : 'example.org',
  user            : 'bob',
  password        : 'secret',
  database        : 'my_db'
});

app.use((req,res,next)=>{
	res.header("Access-Control-Allow-Origin", "*");
	next();
});

app.get("/", (req,res)=>{
	pool.query('SELECT 1 + 1 AS solution', function(error,results,fields){
		if(error)return res.send(error);
		console.log(results);
		res.send("index");
	});
});

app.run(88);