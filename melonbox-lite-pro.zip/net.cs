using MySql.Data.MySqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System;

namespace net {
	class Math {
		public static int add(int a, int b){
			return a+b;
		}
	}
	class Date {
		public static string now(string s){
			return System.DateTime.Now.ToString(s);
		}
	}
	class Mysql {
		public static int invoke(Func<int,int,int> fn, int a, int b){
			return fn(a,b);
		}
		public static DataTable getDataAsync(){
			return Task.Run(()=>getData()).Result;
		}
		public static DataTable getData(){
			try{
				var connstr="data source=db4free.net;database=aardio_mysql;user id=aardio_mysql;password=aardio.com;pooling=false;charset=utf8";
				var conn=new MySqlConnection(connstr);
				conn.Open();
				// MessageBox.Show(conn.ToString());
				var sql="SELECT name FROM library limit 2";
				var cmd = new MySqlCommand(sql,conn);
				// MySqlDataReader reader = cmd.ExecuteReader();
				var data = new MySqlDataAdapter(cmd);
				var ds = new DataSet();
				MessageBox.Show(ds.ToString());
				data.Fill(ds, "library");
				var dt = ds.Tables["library"];
				return dt;
			}catch(MySqlException e){
				MessageBox.Show(e.Message);
				return null;
			}
		}
		public static string getList(){
			try{
				// var dll=Assembly.Load(System.IO.File.ReadAllBytes("MySql.Data.dll"));
				// Type mysql=dll.GetType("MySql.Data.MySqlClient");
				var connstr="data source=db4free.net;database=aardio_mysql;user id=aardio_mysql;password=aardio.com;pooling=false;charset=utf8";
				var conn=new MySqlConnection(connstr);
				conn.Open();
				MessageBox.Show(conn.ToString());
				var sql="SELECT name FROM library limit 2";
				var cmd = new MySqlCommand(sql,conn);
				var reader = cmd.ExecuteReader();
				string res="[res]";
				while(reader.Read()){
					res+=reader.GetString("name");
				}
				reader.Close();
				conn.Close();
				return res;
			}catch(MySqlException e){
				// MessageBox.Show(e.Message);
				return "Error:"+e.Message;
			}
		}
	}
}