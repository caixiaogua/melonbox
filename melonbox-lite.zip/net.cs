
namespace net {
	class Math {
		public static int add(int a, int b){
			return a+b;
		}
	}
	class Date {
		public static string now(string s){
			return System.DateTime.Now.ToString(s);
		}
	}
}