using System.Web.Script.Serialization;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System;

namespace net {
	class Math {
		public static int add(int a, int b){
			return a+b;
		}
	}
	class Date {
		public static string now(string s){
			return System.DateTime.Now.ToString(s);
		}
	}
	class Http {
		public static string get(string url){
			var res=System.Net.WebRequest.Create(url).GetResponse();
			return new System.IO.StreamReader(res.GetResponseStream()).ReadToEnd();
		}
	}
	class Mysql {
		public MySqlConnection mysql;
		static JavaScriptSerializer JSON=new JavaScriptSerializer();
		public static int invoke(Func<int,int,int> fn, int a, int b){
			return fn(a,b);
		}
		// public static DataTable getDataAsync(){
		// 	return Task.Run(()=>getData()).Result;
		// }
		public static Mysql init(string s){
			var connstr=(s!="test"?s:"data source=localhost;database=testdb;user id=root;password=root");
			var conn=new MySqlConnection(connstr);
			conn.Open();
			var _mysql=new Mysql();
			_mysql.mysql=conn;
			return _mysql;
		}
		public string getData(string sql){
			try{
				var conn=this.mysql;
				// MessageBox.Show(conn.ToString());
				// var sql="SELECT * FROM users limit 6";
				var cmd = new MySqlCommand(sql,conn);
				// MySqlDataReader reader = cmd.ExecuteReader();
				// var data = new MySqlDataAdapter(cmd);
				var reader = cmd.ExecuteReader();
				var dt=new DataTable();
				dt.Load(reader);
				return TableToJson(dt);
			}catch(MySqlException e){
				MessageBox.Show(e.Message);
				return null;
			}
		}
		public static string TableToJson(DataTable table)
		{
			JavaScriptSerializer jsSerializer = new JavaScriptSerializer();
			List < Dictionary < string, object >> parentRow = new List < Dictionary < string, object >> ();
			Dictionary < string, object > childRow;
			foreach(DataRow row in table.Rows)
			{
			childRow = new Dictionary < string, object > ();
			foreach(DataColumn col in table.Columns)
			{
			childRow.Add(col.ColumnName, row[col]);
			}
			parentRow.Add(childRow);
			}
			return jsSerializer.Serialize(parentRow);
		}
	}
}